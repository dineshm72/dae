import { warn, debug, debugEnabled, error } from "../dae.js";
import { expireEffects, getActorEffects, daeMacro, actionQueue, resolveEffectExpiryAction } from "./dae.js";
export let expireRoundEffectsOnCombatEnd = false;
export function fetchDurationParams() {
    expireRoundEffectsOnCombatEnd = game.settings.get("dae", "expireRoundEffectsOnCombatEnd");
}
// ---- Duration helpers ----
function getExpireTransferEffectUpdate(effect) {
    return {
        "disabled": true,
        "start.time": null,
        "start.round": null,
        "start.turn": null,
        "duration.expired": false
    };
}
// ---- Exported utility functions ----
/**
 * Expire an effect. Transfer effects are disabled instead of deleted (except applied enchantments).
 */
export async function expireEffect(effect, options = {}) {
    if (debugEnabled > 0)
        warn("Expire effect", effect.uuid, effect);
    if (isTransferEffect(effect)) {
        if (isAppliedEnchantment(effect)) {
            await effect.delete(options);
        }
        else {
            const update = getExpireTransferEffectUpdate(effect);
            await effect.update(update, options);
        }
    }
    else {
        if (game.system?.id === "dnd5e") {
            // An effect whose concentration has ended is left to the concentration's removal
            const origin = fromUuidSync(effect.origin);
            //@ts-expect-error
            if (origin instanceof ActiveEffect && origin.statuses?.has(CONFIG.specialStatusEffects.CONCENTRATING)) {
                const concentrationDuration = origin.updateDuration();
                // concentration expired: let its removal handle dependents
                // @ts-expect-error v14 duration.secondsRemaining
                if (!((concentrationDuration.secondsRemaining ?? concentrationDuration.remaining) > 0))
                    return;
            }
        }
        // Respect per-effect expiry mode, falling back to global setting
        if (resolveEffectExpiryAction(effect) === "delete") {
            await effect.delete(options);
        }
        else {
            /*
             * "Suppress": keep the effect but stop it applying, by disabling it.
             *
             * Not `duration.expired`. dnd5e deletes any effect carrying that flag once the actor has no
             * combatant (ActiveEffect5e._onUpdate), and it does so regardless of
             * CONFIG.ActiveEffect.expiryAction — measured under "update", "delete" and null alike. Using
             * the flag to mean "keep" therefore deletes the very effect the caller asked to keep.
             * `disabled` says the same thing, is what the transfer-effect path above already uses, and is
             * a field the system does not act on.
             */
            await effect.update({ "disabled": true, "duration.expired": false }, options);
        }
    }
}
/**
 * Check if an effect is expired, using v14's native duration calculations.
 */
export function isEffectExpired(effect /* ActiveEffect */) {
    if (effect.duration?.expired)
        return true;
    if (!effect.isTemporary)
        return false;
    const duration = effect.updateDuration();
    return duration.remaining <= 0 && Number.isFinite(duration.remaining);
}
export function isTransferEffect(effect) {
    return effect.transfer;
}
/**
 * Check if an effect is an applied enchantment (dnd5e specific).
 */
export function isAppliedEnchantment(effect) {
    return effect.isAppliedEnchantment ?? false;
}
/**
 * Check if there's a circular dependency between effects.
 */
function hasCircularDependency(startUuid, expiringUuids, maxDepth = 10) {
    const visited = new Set();
    function checkDependencyChain(currentUuid, depth) {
        if (depth > maxDepth)
            return false;
        if (visited.has(currentUuid))
            return false;
        visited.add(currentUuid);
        const effect = fromUuidSync(currentUuid);
        if (!effect)
            return false;
        const dependentOn = foundry.utils.getProperty(effect, "flags.dnd5e.dependentOn");
        if (!dependentOn)
            return false;
        if (dependentOn === startUuid)
            return true;
        if (expiringUuids.has(dependentOn)) {
            return checkDependencyChain(dependentOn, depth + 1);
        }
        return false;
    }
    const startEffect = fromUuidSync(startUuid);
    if (!startEffect)
        return false;
    const startDependentOn = foundry.utils.getProperty(startEffect, "flags.dnd5e.dependentOn");
    if (!startDependentOn || !expiringUuids.has(startDependentOn))
        return false;
    return checkDependencyChain(startDependentOn, 0);
}
/**
 * Expire a list of effects, handling dependent effects that should be skipped.
 */
async function expireEffectsSkipDependents(effectsToExpire, expiringUuids, logPrefix) {
    const deletionInitiated = new Set();
    for (let { effect, reason } of effectsToExpire) {
        if (deletionInitiated.has(effect.uuid)) {
            if (debugEnabled > 0)
                warn("deletion already initiated, skipping", effect.name, effect.uuid);
            continue;
        }
        const parentEffects = effect.parent?.effects;
        if (parentEffects && effect.id && !parentEffects.has(effect.id)) {
            if (debugEnabled > 0)
                warn("effect already deleted, skipping", effect.name, effect.uuid);
            continue;
        }
        const dependentOn = foundry.utils.getProperty(effect, "flags.dnd5e.dependentOn");
        if (dependentOn && expiringUuids.has(dependentOn)) {
            if (hasCircularDependency(effect.uuid, expiringUuids)) {
                warn("circular dependency detected, deleting to break cycle", effect.name, effect.uuid, "dependentOn:", dependentOn);
                deletionInitiated.add(dependentOn);
            }
            else {
                if (debugEnabled > 0)
                    warn("skipping dependent effect (dependentOn also expiring)", effect.name, effect.uuid, "dependentOn:", dependentOn);
                continue;
            }
        }
        if (debugEnabled > 0)
            warn(logPrefix, effect.name, effect.updateDuration(), isTransferEffect(effect), reason);
        deletionInitiated.add(effect.uuid);
        await expireEffect(effect, { "expiry-reason": reason });
    }
}
export function hasDuration(effect) {
    return hasExpiry(effect);
}
export function hasExpiry(effect) {
    const duration = effect?.duration ?? effect;
    const start = effect?.start;
    return !!duration
        && (Number.isFinite(duration.value) || !!duration.expiry)
        && (start?.round != null || start?.turn != null || start?.time != null);
}
// ---- Macro Repeat helpers ----
export function getMacroRepeat(effectData) {
    return effectData.flags?.dae?.macroRepeat;
}
// ---- Macro Repeat processing on turn change ----
export function processMacroRepeats(combat, update, options) {
    const totalTurns = combat.combatants?.contents.length ?? 0;
    let combatantIndex = 0;
    for (let combatant of combat.turns) {
        if (combatant.actor) {
            let actor = combatant.actor;
            const checkTurn = (update.round ?? combat.round) * totalTurns + (update.turn ?? combat.turn ?? 0);
            let lastCheckedTurn = (foundry.utils.getProperty(options, "dae.combat.round") ?? combat.round) * totalTurns
                + (foundry.utils.getProperty(options, "dae.combat.turn") ?? combat.turn);
            const advanced1Turn = lastCheckedTurn + 1 === checkTurn;
            let combatantNextTurn = (update.round ?? combat.round) * totalTurns + combatantIndex;
            if (combatantNextTurn < checkTurn)
                combatantNextTurn += totalTurns;
            let combatantLastTurn = (foundry.utils.getProperty(options, "dae.combat.round") ?? combat.round) * totalTurns + combatantIndex;
            for (let effect of getActorEffects(actor, { includeEnchantments: true })) {
                const macroRepeat = getMacroRepeat(effect);
                switch (macroRepeat) {
                    case "startEveryTurn":
                    case "startEveryTurnAny":
                    case "startEndEveryTurn":
                    case "startEndEveryTurnAny":
                        if ((checkTurn >= combatantLastTurn && lastCheckedTurn < combatantLastTurn) || checkTurn === combatantNextTurn) {
                            if (!(["startEveryTurn", "startEndEveryTurn"].includes(macroRepeat)) || (!effect.disabled && !effect.isSuppressed))
                                daeMacro("each", actor, effect, { actor, effectId: effect.id, tokenId: combatant.token?.id, actorUuid: actor.uuid, actorID: actor.id, efData: effect.toObject(), turn: "startTurn" });
                        }
                        if (["startEveryTurn", "startEveryTurnAny"].includes(macroRepeat))
                            break;
                    case "endEveryTurn":
                    case "endEveryTurnAny":
                        if ((advanced1Turn && combatantLastTurn + 1 === checkTurn)
                            || (!advanced1Turn && combatantLastTurn < checkTurn && combatantLastTurn >= lastCheckedTurn)) {
                            if (["endEveryTurn", "startEndEveryTurn"].includes(macroRepeat) && (effect.disabled || effect.isSuppressed))
                                break;
                            daeMacro("each", actor, effect, { actor, effectId: effect.id, tokenId: combatant.token?.id, actorUuid: actor.uuid, actorID: actor.id, efData: effect.toObject(), turn: "endTurn" });
                        }
                        break;
                }
            }
        }
        combatantIndex += 1;
    }
}
// ---- Expire round effects when combat ends ----
async function expireRoundEffectsOnEnd(actor, combat) {
    if (!expireRoundEffectsOnCombatEnd)
        return;
    const effectsToExpire = [];
    const expiringUuids = new Set();
    for (let effect of getActorEffects(actor, { includeEnchantments: true })) {
        // an expired effect is deleted as its combatant leaves (_onExit); an effect started in another combat stays
        if (effect.duration?.expired)
            continue;
        const started = effect.start?.combat;
        if (started && (started.id ?? started) !== combat.id)
            continue;
        const expiry = effect.duration?.expiry;
        const turnExpiries = ["roundStart", "roundEnd", "turnStart", "turnEnd"];
        // A duration in time units outlasts the combat (dnd5e gives these Turn Start in combat). Read the source:
        // with no combat, core prepares round and turn durations as seconds.
        const { units, value } = effect._source.duration ?? {};
        // @ts-expect-error v14 CONST.ACTIVE_EFFECT_TIME_DURATION_UNITS not in fvtt-types yet
        const timed = CONST.ACTIVE_EFFECT_TIME_DURATION_UNITS.includes(units) && Number.isFinite(value);
        if (turnExpiries.includes(expiry) && !timed && !isTransferEffect(effect)) {
            effectsToExpire.push({ effect, reason: "dae:expired:combat-end-rounds" });
            expiringUuids.add(effect.uuid);
        }
    }
    if (effectsToExpire.length > 0) {
        await expireEffectsSkipDependents(effectsToExpire, expiringUuids, "end combat expired effect");
    }
}
// ---- Migrate deprecated special durations to v14 duration.expiry ----
// Both DAE (dnd5e < 6.0, which registers these events and converts them to core turnStart/turnEnd +
// start.combatant itself) and dnd5e 6.0+ (native PSEUDO_EXPIRIES sourceStart/sourceEnd/targetStart/
// targetEnd) understand the same expiry names, so one map serves both. Previously the 6.0+ branch
// mapped source/target → plain turnStart/turnEnd, silently dropping the source/target distinction now
// that dnd5e 6.0 handles these values natively (confirmed in PR #6837).
export function getDeprecatedSpecialDurMap() {
    return {
        "turnStart": "targetStart",
        "turnEnd": "targetEnd",
        "turnStartSource": "sourceStart",
        "turnEndSource": "sourceEnd",
        "combatEnd": "combatEnd"
    };
}
/**
 * The expiry event deprecated special durations become, and what stays on the flag. Only one can take
 * duration.expiry. An authored expiry is kept (core's schema gives any numeric duration "turnStart", so only an expiry
 * differing from that counts), and entries it already holds are dropped. combatEnd yields the slot, as it still works
 * as a special duration and source/target entries left on the flag do nothing; on an effect with a duration it never
 * takes it (as its expiry event the effect would end only at the first combat end after the duration).
 * `duration` is source data.
 */
export function migratedSpecialDurations(duration, specialDurs) {
    const map = getDeprecatedSpecialDurMap();
    const hasValue = typeof duration?.value === "number";
    const authored = duration?.expiry && duration.expiry !== (hasValue ? "turnStart" : null) ? duration.expiry : null;
    // (combatEnd on an effect with a duration is not the same as that expiry: it stays)
    let remaining = specialDurs.filter(sd => !(authored && map[sd] === authored && !(hasValue && sd === "combatEnd")));
    let expiry = authored;
    if (!authored) {
        const first = remaining.find(sd => sd in map && sd !== "combatEnd") ?? (hasValue ? undefined : remaining.find(sd => sd === "combatEnd"));
        if (first) {
            expiry = map[first];
            remaining = remaining.filter(sd => sd !== first);
        }
    }
    if (!expiry || (expiry === authored && remaining.length === specialDurs.length))
        return null;
    return { expiry, remaining };
}
function migrateDeprecatedSpecialDurations(effectData) {
    const specialDurs = effectData.flags?.dae?.specialDuration;
    if (!Array.isArray(specialDurs))
        return;
    // the pending document is prepared: an unset duration reads Infinity
    const migrated = migratedSpecialDurations(effectData._source?.duration ?? effectData.duration, specialDurs);
    if (!migrated)
        return;
    if (debugEnabled > 0)
        warn("Migrating deprecated special duration on effect creation", effectData.name, "→", migrated.expiry);
    effectData.updateSource({ "duration.expiry": migrated.expiry, "flags.dae.specialDuration": migrated.remaining });
}
// ---- Combat End expiry (special duration) ----
export function preDeleteCombatHook(combat, options, user) {
    if (user !== game.user?.id)
        return;
    for (let combatant of combat.combatants) {
        const actor = combatant.actor;
        if (!actor)
            continue;
        /*
         * dnd5e 6 deletes an effect with a combat pseudo-expiry (targetStart and the like) itself as its
         * combatant leaves the combat (Combat5e#_onExit). Expiring it here as well raced that and threw
         * "does not exist" — midi's reaction marker carries both targetStart and combatEnd.
         */
        const systemRemoves = (ef) => {
            if (!ef.specialDuration)
                return false;
            const start = ef.start?.combat;
            return !start || start === combat || start === combat.id || start?.id === combat.id;
        };
        const effects = getActorEffects(actor, { includeEnchantments: true })
            .filter(ef => ef.flags?.dae?.specialDuration?.includes("combatEnd") && !ef.duration?.expired && !systemRemoves(ef));
        actionQueue.add(expireEffects, actor, effects, { "expiry-reason": "combat-end" });
    }
}
// ---- Join Combat expiry (special duration) ----
export function preCreateCombatantHook(combatant, data, options, user) {
    const actor = combatant.actor;
    if (!actor)
        return;
    const effects = getActorEffects(actor, { includeEnchantments: true })
        .filter(ef => ef.flags?.dae?.specialDuration?.includes("joinCombat"));
    actionQueue.add(expireEffects, actor, effects, { "expiry-reason": "join-combat" });
}
// ---- Hook registration ----
// @ts-expect-error v14 game.users.activeGM not in fvtt-types yet
function isResponsibleGM() { return game.users.activeGM?.isSelf; }
export function setupSpecialDurationHooks() {
    Hooks.on("preDeleteCombat", preDeleteCombatHook);
    Hooks.on("preCreateCombatant", preCreateCombatantHook);
    Hooks.on("preUpdateCombat", (combat, update, options, user) => {
        foundry.utils.setProperty(options, "dae.combat.round", combat.round);
        foundry.utils.setProperty(options, "dae.combat.turn", combat.turn);
        return true;
    });
    Hooks.on("updateCombat", async (combat, update, options, user) => {
        // @ts-expect-error v14 game.users.activeGM not in fvtt-types yet
        if (!game.users.activeGM?.isSelf)
            return;
        if (update.round === undefined && update.turn === undefined)
            return;
        if (debugEnabled > 1)
            debug("updateCombat (macro repeats)", combat, update, options);
        processMacroRepeats(combat, update, options);
    });
    // --- Duration management hooks (formerly times-up) ---
    Hooks.on("preCreateActiveEffect", (effectData, options, user) => {
        try {
            migrateDeprecatedSpecialDurations(effectData);
        }
        catch (err) {
            error("preCreateActiveEffect error", err);
        }
        finally {
            return true;
        }
    });
    Hooks.on("deleteCombatant", async (combatant) => {
        if (!isResponsibleGM() || !combatant.actor)
            return;
        await expireRoundEffectsOnEnd(combatant.actor, combatant.combat);
    });
    Hooks.on("deleteCombat", async (combat) => {
        if (!isResponsibleGM())
            return;
        for (let combatant of combat.combatants) {
            if (!combatant.actor)
                continue;
            await expireRoundEffectsOnEnd(combatant.actor, combat);
        }
    });
}
